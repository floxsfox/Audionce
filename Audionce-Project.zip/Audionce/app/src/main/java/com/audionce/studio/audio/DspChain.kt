package com.audionce.studio.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Parameter efek untuk satu blok. spatialMode: 0 off, 1 = 3D, 2 = 8D, 3 = 10D. */
class DspParams(
    val rate: Double,
    val reverbOn: Boolean,
    val wet: Float,
    val spatialMode: Int,
    val intensity: Float,
    val speed: Float
)

/**
 * Rantai pemrosesan satu blok, dipakai pemutar langsung dan render offline (export):
 * resample (slowed) -> reverb konvolusi (dry 1.0 + wet) -> spatial.
 */
class DspChain(private val sampleRate: Int) {
    val blockSize = PartitionedConvolver.BLOCK

    /** Jumlah frame yang valid pada blok terakhir (kurang dari blockSize jika audio habis). */
    var validFrames = blockSize
        private set

    private val dryL = FloatArray(blockSize)
    private val dryR = FloatArray(blockSize)
    private val wetL = FloatArray(blockSize)
    private val wetR = FloatArray(blockSize)
    private var wetCur = 0f
    private var convSkipped = true
    private val pans = FloatArray(2)

    fun renderBlock(
        pcm: PcmData,
        posIn: Double,
        p: DspParams,
        conv: PartitionedConvolver?,
        loop: Boolean,
        timeSec: Double,
        outL: FloatArray,
        outR: FloatArray
    ): Double {
        val frames = pcm.frames
        val s = pcm.samples
        var pos = posIn
        var valid = blockSize
        val inv16 = 1f / 32768f

        // 1) resample (playbackRate)
        for (i in 0 until blockSize) {
            if (pos >= frames.toDouble()) {
                if (loop && frames > 0) {
                    pos -= frames.toDouble()
                } else {
                    dryL[i] = 0f
                    dryR[i] = 0f
                    if (valid > i) valid = i
                    pos += p.rate
                    continue
                }
            }
            val i0 = pos.toInt()
            val f = (pos - i0.toDouble()).toFloat()
            val i1 = if (i0 + 1 < frames) i0 + 1 else if (loop) 0 else i0
            val a = i0 * 2
            val c = i1 * 2
            val l0 = s[a].toFloat()
            val l1 = s[c].toFloat()
            val r0 = s[a + 1].toFloat()
            val r1 = s[c + 1].toFloat()
            dryL[i] = (l0 + (l1 - l0) * f) * inv16
            dryR[i] = (r0 + (r1 - r0) * f) * inv16
            pos += p.rate
        }
        validFrames = valid

        // 2) reverb: dry 1.0 + wet (ramp halus agar tidak klik)
        val target = if (p.reverbOn) p.wet else 0f
        val wetStart = wetCur
        wetCur = target
        if (conv != null && (wetStart > 0f || target > 0f)) {
            if (convSkipped) {
                conv.reset()
                convSkipped = false
            }
            conv.process(dryL, dryR, wetL, wetR)
            for (i in 0 until blockSize) {
                val g = wetStart + (target - wetStart) * ((i + 1).toFloat() / blockSize.toFloat())
                outL[i] = dryL[i] + wetL[i] * g
                outR[i] = dryR[i] + wetR[i] * g
            }
        } else {
            convSkipped = true
            System.arraycopy(dryL, 0, outL, 0, blockSize)
            System.arraycopy(dryR, 0, outR, 0, blockSize)
        }

        // 3) spatial (sama dengan rantai splitter -> stereo panner -> merger pada HTML)
        if (p.spatialMode != 0) {
            val blockDur = blockSize.toDouble() / sampleRate.toDouble()
            panValues(p.spatialMode, timeSec, p.intensity, p.speed)
            val gl0 = panGain(pans[0])
            val gr0 = panGain(pans[1])
            panValues(p.spatialMode, timeSec + blockDur, p.intensity, p.speed)
            val gl1 = panGain(pans[0])
            val gr1 = panGain(pans[1])
            for (i in 0 until blockSize) {
                val u = (i + 1).toFloat() / blockSize.toFloat()
                outL[i] = outL[i] * (gl0 + (gl1 - gl0) * u)
                outR[i] = outR[i] * (gr0 + (gr1 - gr0) * u)
            }
        }
        return pos
    }

    /** Nilai pan kiri/kanan menurut updateSpatialAudio() pada HTML. */
    private fun panValues(mode: Int, t: Double, intensity: Float, speed: Float) {
        val inten = intensity.toDouble()
        val spd = speed.toDouble()
        when (mode) {
            1 -> {
                val angle = sin(t * spd) * inten * 0.35
                pans[0] = (-angle).toFloat()
                pans[1] = angle.toFloat()
            }
            2 -> {
                val angle = (t * spd) % (PI * 2.0)
                val pan = sin(angle) * inten
                pans[0] = (-pan).toFloat()
                pans[1] = pan.toFloat()
            }
            else -> {
                val a1 = sin(t * spd * 0.7) * inten * 0.65
                val a2 = cos(t * spd * 1.3) * inten * 0.45
                val v = (a1 + a2) * 0.5
                pans[0] = (-v).toFloat()
                pans[1] = v.toFloat()
            }
        }
    }

    /** StereoPanner (input mono) lalu di-downmix ke mono oleh ChannelMerger: 0.5 * (cos x + sin x). */
    private fun panGain(pan: Float): Float {
        val p = pan.coerceIn(-1f, 1f)
        val x = (p + 1f) * (PI.toFloat() / 4f)
        return 0.5f * (cos(x) + sin(x))
    }
}
