package com.audionce.studio.export

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Menyimpan hasil export ke Music/Audionce atau Movies/Audionce lewat MediaStore (tanpa izin tambahan). */
object MediaSaver {

    fun createUri(ctx: Context, displayName: String, mime: String, video: Boolean): Uri? {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        val folder = if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/Audionce")
        values.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val collection = if (video) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        return ctx.contentResolver.insert(collection, values)
    }

    fun finish(ctx: Context, uri: Uri) {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        ctx.contentResolver.update(uri, values, null, null)
    }

    fun discard(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.delete(uri, null, null)
        } catch (e: Exception) {
        }
    }

    /** Tulis WAV 16-bit PCM. */
    fun writeWav(ctx: Context, uri: Uri, audio: RenderedAudio, progress: (Float) -> Unit) {
        val os = ctx.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Tidak bisa membuka file tujuan")
        os.use { raw ->
            val out = BufferedOutputStream(raw, 1 shl 16)
            val dataSize = audio.frames * 2 * 2
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray(Charsets.US_ASCII))
            h.putInt(36 + dataSize)
            h.put("WAVE".toByteArray(Charsets.US_ASCII))
            h.put("fmt ".toByteArray(Charsets.US_ASCII))
            h.putInt(16)
            h.putShort(1)
            h.putShort(2)
            h.putInt(audio.sampleRate)
            h.putInt(audio.sampleRate * 2 * 2)
            h.putShort(4)
            h.putShort(16)
            h.put("data".toByteArray(Charsets.US_ASCII))
            h.putInt(dataSize)
            out.write(h.array())

            val chunkFrames = 8192
            val bb = ByteBuffer.allocate(chunkFrames * 4).order(ByteOrder.LITTLE_ENDIAN)
            var f = 0
            while (f < audio.frames) {
                val n = Math.min(chunkFrames, audio.frames - f)
                bb.clear()
                for (i in 0 until n * 2) bb.putShort(audio.samples[f * 2 + i])
                out.write(bb.array(), 0, n * 4)
                f += n
                progress(f.toFloat() / audio.frames.toFloat())
            }
            out.flush()
        }
    }
}
