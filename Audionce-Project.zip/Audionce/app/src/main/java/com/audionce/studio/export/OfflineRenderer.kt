package com.audionce.studio.export

import com.audionce.studio.audio.DspChain
import com.audionce.studio.audio.DspParams
import com.audionce.studio.audio.PartitionedConvolver
import com.audionce.studio.audio.PcmData
import com.audionce.studio.audio.ReverbIr

/** Hasil render: stereo 16-bit ter-interleave. */
class RenderedAudio(val samples: ShortArray, val frames: Int, val sampleRate: Int)

/** Render offline dengan efek terpilih (setara renderOfflineAudio() di HTML). */
object OfflineRenderer {
    fun render(
        pcm: PcmData,
        rate: Double,
        reverb: Boolean,
        wet: Float,
        roomSize: Float,
        decay: Float,
        spatialMode: Int,
        intensity: Float,
        speed: Float,
        progress: (Float) -> Unit
    ): RenderedAudio {
        val sr = pcm.sampleRate
        val outFrames = Math.ceil(pcm.frames.toDouble() / rate).toInt()
        val out = ShortArray(outFrames * 2)
        val chain = DspChain(sr)
        val conv: PartitionedConvolver? =
            if (reverb) PartitionedConvolver(ReverbIr.generate(sr, roomSize, decay, false), sr, true) else null
        val params = DspParams(rate, reverb, wet, spatialMode, intensity, speed)
        val block = chain.blockSize
        val outL = FloatArray(block)
        val outR = FloatArray(block)

        var pos = 0.0
        var written = 0
        while (written < outFrames) {
            val tSec = written.toDouble() / sr.toDouble()
            pos = chain.renderBlock(pcm, pos, params, conv, false, tSec, outL, outR)
            val n = Math.min(block, outFrames - written)
            for (i in 0 until n) {
                out[(written + i) * 2] = toShort(outL[i])
                out[(written + i) * 2 + 1] = toShort(outR[i])
            }
            written += n
            progress(written.toFloat() / outFrames.toFloat())
        }
        return RenderedAudio(out, outFrames, sr)
    }

    private fun toShort(v: Float): Short {
        val x = (v * 32767f).toInt()
        return x.coerceIn(-32768, 32767).toShort()
    }
}
