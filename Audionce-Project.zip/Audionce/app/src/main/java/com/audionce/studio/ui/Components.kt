package com.audionce.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Pal {
    val bg = Color(0xFF0A0A0B)
    val surface = Color(0xFF121214)
    val surface2 = Color(0xFF18181B)
    val surface3 = Color(0xFF1F1F23)
    val border = Color(0xFF28282E)
    val border2 = Color(0xFF33333A)
    val text = Color(0xFFEDEEF0)
    val dim = Color(0xFF9A9BA3)
    val muted = Color(0xFF5A5B64)
    val accent1 = Color(0xFF06B6D4)
    val accent2 = Color(0xFF8B5CF6)
    val accentSoft = Color(0x148B5CF6)
    val green = Color(0xFF10B981)
    val red = Color(0xFFEF4444)
    val waveRed = Color(0xFFFF3344)
}

val AccentBrush: Brush = Brush.linearGradient(listOf(Pal.accent1, Pal.accent2))

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier {
    return this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

/** Teks dasar. mono = JetBrains Mono (diganti font monospace sistem). */
@Composable
fun T(
    text: String,
    size: Float = 14f,
    color: Color = Pal.text,
    mono: Boolean = false,
    weight: FontWeight = FontWeight.Normal,
    spacing: Float = 0f,
    modifier: Modifier = Modifier,
    align: TextAlign = TextAlign.Start,
    maxLines: Int = Int.MAX_VALUE,
    brush: Brush? = null
) {
    val family = if (mono) FontFamily.Monospace else FontFamily.Default
    val style = if (brush != null) {
        TextStyle(
            brush = brush,
            fontSize = size.sp,
            fontWeight = weight,
            fontFamily = family,
            letterSpacing = spacing.sp,
            textAlign = align
        )
    } else {
        TextStyle(
            color = color,
            fontSize = size.sp,
            fontWeight = weight,
            fontFamily = family,
            letterSpacing = spacing.sp,
            textAlign = align
        )
    }
    BasicText(
        text = text,
        modifier = modifier,
        style = style,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun SvgIcon(spec: IconSpec, dp: Dp, color: Color, stroke: Float = 2f, modifier: Modifier = Modifier) {
    val paths = remember(spec) { spec.paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(modifier.size(dp)) {
        val s = this.size.minDimension / 24f
        scale(s, s, pivot = Offset.Zero) {
            if (spec.filled) {
                for (p in paths) drawPath(p, color, style = Fill)
                for (c in spec.circles) drawCircle(color, radius = c[2], center = Offset(c[0], c[1]), style = Fill)
            } else {
                val st = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
                for (p in paths) drawPath(p, color, style = st)
                for (c in spec.circles) drawCircle(color, radius = c[2], center = Offset(c[0], c[1]), style = st)
            }
        }
    }
}

/** Slider tipis dengan thumb gradien (gaya sama dengan input range pada HTML). */
@Composable
fun NSlider(
    value: Float,
    onChange: (Float) -> Unit,
    min: Float,
    max: Float,
    step: Float,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    val cb by rememberUpdatedState(onChange)
    val on by rememberUpdatedState(enabled)

    fun valueAt(x: Float): Float {
        val f = (x / widthPx).coerceIn(0f, 1f)
        var v = min + f * (max - min)
        if (step > 0f) v = Math.round((v - min) / step) * step + min
        return v.coerceIn(min, max)
    }

    Box(
        modifier
            .height(28.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(min, max, step) {
                detectTapGestures { off -> if (on) cb(valueAt(off.x)) }
            }
            .pointerInput(min, max, step) {
                detectHorizontalDragGestures(
                    onDragStart = { off -> if (on) cb(valueAt(off.x)) }
                ) { change, _ ->
                    change.consume()
                    if (on) cb(valueAt(change.position.x))
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val trackH = 4.dp.toPx()
            val thumbR = 8.dp.toPx()
            val cy = size.height / 2f
            val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
            val usable = size.width - thumbR * 2f
            drawRoundRect(
                color = Pal.surface3,
                topLeft = Offset(thumbR, cy - trackH / 2f),
                size = androidx.compose.ui.geometry.Size(usable, trackH),
                cornerRadius = CornerRadius(trackH / 2f, trackH / 2f)
            )
            val cx = thumbR + usable * frac
            drawCircle(brush = AccentBrush, radius = thumbR, center = Offset(cx, cy))
        }
    }
}

@Composable
fun NToggle(checked: Boolean, onToggle: () -> Unit) {
    Box(
        Modifier
            .width(46.dp)
            .height(26.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(if (checked) Pal.accent2.copy(alpha = 0.35f) else Pal.surface3)
            .border(1.dp, if (checked) Pal.accent2 else Pal.border2, RoundedCornerShape(13.dp))
            .tap(onToggle)
    ) {
        Box(
            Modifier
                .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                .padding(3.dp)
                .size(18.dp)
                .clip(CircleShape)
                .background(if (checked) Pal.accent2 else Pal.muted)
        )
    }
}

@Composable
fun Badge(text: String, active: Boolean) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (active) Pal.accentSoft else Color.Transparent)
            .border(1.dp, if (active) Pal.accent2 else Pal.border2, shape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        T(text.uppercase(), 9.5f, if (active) Pal.accent2 else Pal.muted, mono = true, spacing = 1.2f)
    }
}

@Composable
fun Panel(title: String, badge: String?, badgeActive: Boolean, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.surface)
            .border(1.dp, Pal.border, shape)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            T(title.uppercase(), 12f, Pal.dim, mono = true, spacing = 2f)
            if (badge != null) Badge(badge, badgeActive)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.border))
        Column(Modifier.padding(20.dp)) { content() }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    valueText: String,
    min: Float,
    max: Float,
    step: Float,
    enabled: Boolean = true,
    onChange: (Float) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        T(label, 11f, Pal.muted, mono = true, modifier = Modifier.width(52.dp))
        NSlider(value, onChange, min, max, step, Modifier.weight(1f), enabled)
        T(valueText, 11f, Pal.accent2, mono = true, align = TextAlign.End, modifier = Modifier.width(52.dp))
    }
}

@Composable
fun SquareButton(icon: IconSpec, active: Boolean, onClick: () -> Unit, dpSize: Dp = 40.dp, iconDp: Dp = 17.dp) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .size(dpSize)
            .clip(shape)
            .background(if (active) Pal.accentSoft else Pal.surface2)
            .border(1.dp, if (active) Pal.accent2 else Pal.border2, shape)
            .tap(onClick),
        contentAlignment = Alignment.Center
    ) {
        SvgIcon(icon, iconDp, if (active) Pal.accent2 else Pal.dim)
    }
}

@Composable
fun GradientButton(text: String, icon: IconSpec?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier
            .clip(shape)
            .background(AccentBrush)
            .tap(onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (icon != null) SvgIcon(icon, 14.dp, Color.White, 2.5f)
        T(text.uppercase(), 11f, Color.White, mono = true, spacing = 1.5f, weight = FontWeight.Medium)
    }
}

@Composable
fun OutlineButton(text: String, icon: IconSpec?, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier
            .clip(shape)
            .background(if (active) Pal.accentSoft else Pal.surface2)
            .border(1.dp, if (active) Pal.accent2 else Pal.border2, shape)
            .tap(onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            SvgIcon(icon, 15.dp, if (active) Pal.accent2 else Pal.dim)
            Box(Modifier.width(8.dp))
        }
        T(text, 12f, if (active) Pal.accent2 else Pal.dim, mono = true, spacing = 0.5f)
    }
}

@Composable
fun RadioDot(selected: Boolean) {
    Canvas(Modifier.size(18.dp)) {
        drawCircle(color = if (selected) Pal.accent2 else Pal.dim, radius = size.minDimension / 2f - 1.dp.toPx(), style = Stroke(width = 1.5.dp.toPx()))
        if (selected) drawCircle(color = Pal.accent2, radius = size.minDimension / 4.2f)
    }
}

@Composable
fun CheckBox(checked: Boolean) {
    val shape = RoundedCornerShape(4.dp)
    Box(
        Modifier
            .size(18.dp)
            .clip(shape)
            .background(if (checked) Pal.accent2 else Color.Transparent)
            .border(1.5.dp, if (checked) Pal.accent2 else Pal.dim, shape),
        contentAlignment = Alignment.Center
    ) {
        if (checked) SvgIcon(Icons.check, 12.dp, Color.White, 3f)
    }
}

@Composable
fun DashedBox(modifier: Modifier, radius: Dp, content: @Composable () -> Unit) {
    Box(
        modifier.drawBehind {
            val r = radius.toPx()
            drawRoundRect(
                color = Pal.border2,
                cornerRadius = CornerRadius(r, r),
                style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
            )
        },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun DashedCircle(modifier: Modifier, content: @Composable () -> Unit) {
    Box(
        modifier.drawBehind {
            drawCircle(
                color = Pal.border2,
                radius = size.minDimension / 2f - 2.dp.toPx(),
                style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            )
        },
        contentAlignment = Alignment.Center
    ) { content() }
}
