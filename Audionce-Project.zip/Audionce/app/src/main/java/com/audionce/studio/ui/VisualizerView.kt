package com.audionce.studio.ui

import android.graphics.Paint
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.audionce.studio.AppController
import com.audionce.studio.vis.VisDraw
import com.audionce.studio.vis.WaveCandyEngine
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private class VisState {
    val wave = WaveCandyEngine(0.2f)
    val data = FloatArray(8192)
    val sinTab = FloatArray(8192)
    val cosTab = FloatArray(8192)
    val lines = FloatArray(4 * 1300)
    var idleMix = 1f
    var lastNs = 0L

    val bg = Paint().apply {
        style = Paint.Style.FILL
        color = 0xFF0D0D0E.toInt()
    }
    val waveP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.SQUARE
        strokeWidth = 2f
        color = 0xFFFF3344.toInt()
    }
    val centerP = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = 0x1FFF3344
    }
    val misc = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        val k = (PI * 12.0 / 8192.0).toFloat()
        for (i in 0 until 8192) {
            sinTab[i] = sin(i * k)
            cosTab[i] = cos(i * k)
        }
    }

    fun draw(scope: DrawScope, c: AppController, nowNs: Long) {
        val w = scope.size.width
        val h = scope.size.height
        val dt = if (lastNs == 0L) 0.016f else ((nowNs - lastNs) / 1.0e9f).coerceIn(0f, 0.1f)
        lastNs = nowNs

        // data musik (hanya saat memutar); selain itu animasi idle dengan transisi halus
        val got = c.engine.snapshot(data)
        if (!got) java.util.Arrays.fill(data, 0f)
        val target = if (got) 0f else 1f
        idleMix += (target - idleMix) * (1f - Math.exp((-dt / 0.15f).toDouble()).toFloat())
        if (idleMix < 0.002f) idleMix = 0f else if (idleMix > 0.998f) idleMix = 1f
        if (idleMix > 0f) {
            val tt = SystemClock.uptimeMillis() / 2000.0
            val cs = cos(tt).toFloat()
            val sn = sin(tt).toFloat()
            val keep = 1f - idleMix
            val amp = 0.015f * idleMix
            for (i in 0 until data.size) {
                data[i] = data[i] * keep + amp * (sinTab[i] * cs + cosTab[i] * sn)
            }
        }

        val mode = c.visMode
        scope.drawIntoCanvas { canvas ->
            val cv = canvas.nativeCanvas
            cv.drawRect(0f, 0f, w, h, bg)
            when (mode) {
                1 -> VisDraw.bars(cv, data, w, h, misc)
                2 -> VisDraw.circular(cv, data, w, h, misc)
                else -> {
                    val pts = Math.min(1200, w.toInt())
                    val n = wave.buildLines(data, 0f, h / 2f, w, h / 2f, pts, lines)
                    cv.drawLines(lines, 0, n, waveP)
                    cv.drawLine(0f, h / 2f, w, h / 2f, centerP)
                }
            }
        }
    }
}

@Composable
fun VisualizerView(c: AppController, modifier: Modifier = Modifier) {
    val st = remember { VisState() }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { tick = it }
        }
    }
    Canvas(modifier) {
        val now = tick
        st.draw(this, c, now)
    }
}
