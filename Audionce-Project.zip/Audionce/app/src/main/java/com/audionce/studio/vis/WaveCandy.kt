package com.audionce.studio.vis

import android.graphics.Canvas
import android.graphics.Paint

/**
 * Wave Candy: trigger stabil (korelasi dengan frame sebelumnya + posisi pecahan) dan lebar jendela tetap.
 * Ini terjemahan langsung dari createWaveEngine() di versi HTML.
 */
class WaveCandyEngine(private val searchFrac: Float) {
    private val refN = 128
    private val maxCand = 48
    private val ref = FloatArray(refN)
    private val seg = FloatArray(refN)
    private val cand = FloatArray(maxCand)
    private var hasRef = false
    private var outStart = 0f
    private var xs = FloatArray(0)
    private var ys = FloatArray(0)

    private fun sampleAt(data: FloatArray, p: Float): Float {
        val k = Math.floor(p.toDouble()).toInt()
        val a = if (k >= 0 && k < data.size) data[k] else 0f
        val b = if (k + 1 >= 0 && k + 1 < data.size) data[k + 1] else 0f
        return a + (b - a) * (p - k.toFloat())
    }

    private fun findStart(data: FloatArray) {
        val n = data.size
        val searchEnd = Math.floor((n * searchFrac).toDouble()).toInt()

        var peak = 0f
        var q = 0
        while (q < n) {
            val v = Math.abs(data[q])
            if (v > peak) peak = v
            q += 4
        }
        if (peak < 1e-5f) {
            outStart = 0f
            return
        }

        val h = peak * 0.04f
        var cnt = 0
        var armed = false
        for (j in 1 until searchEnd) {
            val a = data[j - 1]
            val b = data[j]
            if (a < -h) armed = true
            if (armed && a < 0f && b >= 0f) {
                cand[cnt % maxCand] = (j - 1).toFloat() + (-a) / (b - a)
                cnt++
                armed = false
            }
        }
        if (cnt == 0) {
            outStart = 0f
            return
        }

        val count = Math.min(cnt, maxCand)
        val span = Math.min(1024, n - searchEnd - 2)
        val stepR = (span - 1).toFloat() / (refN - 1).toFloat()
        var best = cand[(cnt - 1) % maxCand]

        if (hasRef) {
            var bestScore = Float.NEGATIVE_INFINITY
            for (c in 0 until count) {
                val pos = cand[c]
                var dot = 0f
                var en = 0f
                for (k in 0 until refN) {
                    val v = sampleAt(data, pos + k * stepR)
                    dot += v * ref[k]
                    en += v * v
                }
                val score = dot / Math.sqrt((en + 1e-12f).toDouble()).toFloat()
                if (score > bestScore) {
                    bestScore = score
                    best = pos
                }
            }
        }

        var en2 = 0f
        for (k in 0 until refN) {
            val v = sampleAt(data, best + k * stepR)
            seg[k] = v
            en2 += v * v
        }
        val inv = 1f / Math.sqrt((en2 / refN + 1e-12f).toDouble()).toFloat()
        for (k in 0 until refN) {
            val v = seg[k] * inv
            ref[k] = if (hasRef) ref[k] * 0.5f + v * 0.5f else v
        }
        hasRef = true
        outStart = best
    }

    /** Mengisi out dengan segmen garis (x0,y0,x1,y1 ...). Mengembalikan jumlah float yang terisi. */
    fun buildLines(data: FloatArray, x0: Float, midY: Float, w: Float, halfH: Float, maxPts: Int, out: FloatArray): Int {
        findStart(data)
        val n = data.size
        val win = (n - Math.floor((n * searchFrac).toDouble()).toInt() - 1).toFloat()
        val points = Math.min(Math.max(8, maxPts), out.size / 4)
        if (xs.size < points) {
            xs = FloatArray(points)
            ys = FloatArray(points)
        }
        val step = win / points.toFloat()
        val edge = Math.floor(points * 0.05).toInt()
        for (i in 0 until points) {
            var s = sampleAt(data, outStart + i * step)
            if (i < edge) s *= i.toFloat() / edge.toFloat()
            else if (i > points - edge) s *= (points - i).toFloat() / edge.toFloat()
            xs[i] = x0 + (i.toFloat() / points.toFloat()) * w
            ys[i] = midY + s * halfH * 0.88f
        }
        var o = 0
        for (i in 0 until points - 1) {
            out[o++] = xs[i]
            out[o++] = ys[i]
            out[o++] = xs[i + 1]
            out[o++] = ys[i + 1]
        }
        return o
    }
}

/** Gambar Bars dan Circular (terjemahan drawBars / drawCircular). */
object VisDraw {
    fun hsl(h: Float, s: Float, l: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        val c = (1f - Math.abs(2f * l - 1f)) * s
        val x = c * (1f - Math.abs((hh / 60f) % 2f - 1f))
        val m = l - c / 2f
        var r = 0f
        var g = 0f
        var b = 0f
        when {
            hh < 60f -> { r = c; g = x }
            hh < 120f -> { r = x; g = c }
            hh < 180f -> { g = c; b = x }
            hh < 240f -> { g = x; b = c }
            hh < 300f -> { r = x; b = c }
            else -> { r = c; b = x }
        }
        val ri = Math.round((r + m) * 255f)
        val gi = Math.round((g + m) * 255f)
        val bi = Math.round((b + m) * 255f)
        return (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }

    fun bars(canvas: Canvas, data: FloatArray, w: Float, h: Float, paint: Paint) {
        val bars = 100
        val step = data.size / bars
        val barW = w / bars.toFloat()
        paint.style = Paint.Style.FILL
        for (i in 0 until bars) {
            var sum = 0f
            for (j in 0 until step) sum += Math.abs(data[i * step + j])
            val avg = sum / step.toFloat()
            val barH = avg * h * 1.8f
            val y = h - barH
            val hue = (i.toFloat() / bars.toFloat()) * 120f + 120f
            paint.color = hsl(hue, 0.7f, 0.55f)
            canvas.drawRect(i * barW, y, i * barW + barW - 1f, h, paint)
        }
    }

    fun circular(canvas: Canvas, data: FloatArray, w: Float, h: Float, paint: Paint) {
        val cx = w / 2f
        val cy = h / 2f
        val radius = Math.min(w, h) * 0.22f
        val bars = 100
        val step = data.size / bars
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.strokeCap = Paint.Cap.BUTT
        for (i in 0 until bars) {
            var sum = 0f
            for (j in 0 until step) sum += Math.abs(data[i * step + j])
            val avg = sum / step.toFloat()
            val angle = (i.toFloat() / bars.toFloat()) * (Math.PI * 2.0) - Math.PI / 2.0
            val barLen = avg * radius * 3f
            val cosA = Math.cos(angle).toFloat()
            val sinA = Math.sin(angle).toFloat()
            val hue = (i.toFloat() / bars.toFloat()) * 60f + 160f
            paint.color = hsl(hue, 0.7f, 0.6f)
            canvas.drawLine(cx + cosA * radius, cy + sinA * radius, cx + cosA * (radius + barLen), cy + sinA * (radius + barLen), paint)
        }
        paint.color = 0x66 shl 24 or 0x8B5CF6
        canvas.drawCircle(cx, cy, radius, paint)
    }
}
