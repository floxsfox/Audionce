package com.audionce.studio.audio

/** Audio hasil decode: stereo 16-bit ter-interleave (L,R,L,R,...). */
class PcmData(val samples: ShortArray, val frames: Int, val sampleRate: Int) {
    val durationSec: Double
        get() = frames.toDouble() / sampleRate.toDouble()
}
