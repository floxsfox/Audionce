package com.audionce.studio.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors

/**
 * Mesin pemutar: render blok demi blok lewat DspChain lalu ditulis ke AudioTrack.
 * Juga menyimpan ring buffer sampel terbaru untuk visualizer (Wave Candy).
 */
class PlayerEngine {
    companion object {
        private const val RING = 1 shl 16
        private const val RING_MASK = (RING - 1).toLong()
    }

    @Volatile var pcm: PcmData? = null
    @Volatile var volume: Float = 0.75f
    @Volatile var muted: Boolean = false
    @Volatile var looping: Boolean = false
    @Volatile var rate: Double = 1.0
    @Volatile var reverbOn: Boolean = false
    @Volatile var wet: Float = 0.45f
    @Volatile var roomSize: Float = 2.5f
    @Volatile var decay: Float = 0.7f
    @Volatile var spatialMode: Int = 0
    @Volatile var intensity: Float = 0.7f
    @Volatile var speed: Float = 0.5f

    @Volatile var playing: Boolean = false
        private set

    var onEnded: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    @Volatile private var pausedAtSec: Double = 0.0
    @Volatile private var convolver: PartitionedConvolver? = null
    @Volatile private var irGen: Int = 0
    private val irExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var thread: Thread? = null
    @Volatile private var runFlag: Boolean = false
    @Volatile private var trackRef: AudioTrack? = null
    @Volatile private var framesWritten: Long = 0L
    @Volatile private var posAfterWrite: Double = 0.0

    private val ring = FloatArray(RING)
    @Volatile private var ringWrite: Long = 0L

    // ---------------------------------------------------------------- muat & reverb
    fun load(p: PcmData) {
        pause()
        pcm = p
        pausedAtSec = 0.0
        rebuildReverb()
    }

    /** Dipanggil saat ukuran ruangan / decay berubah (IR dibangun ulang di thread terpisah). */
    fun rebuildReverb() {
        val p = pcm ?: return
        irGen++
        val gen = irGen
        val size = roomSize
        val dec = decay
        irExecutor.execute {
            if (gen != irGen) return@execute
            try {
                val ir = ReverbIr.generate(p.sampleRate, size, dec, true)
                if (gen != irGen) return@execute
                convolver = PartitionedConvolver(ir, p.sampleRate, true)
            } catch (e: Throwable) {
                // memori kurang: reverb dilewati
            }
        }
    }

    // ---------------------------------------------------------------- kontrol
    fun play(fromSec: Double) {
        val p = pcm ?: return
        stopThread()
        val startPos = (fromSec * p.sampleRate).coerceIn(0.0, maxOf(0.0, (p.frames - 1).toDouble()))
        runFlag = true
        playing = true
        posAfterWrite = startPos
        framesWritten = 0L
        val t = Thread(Runnable { runLoop(p, startPos) }, "audionce-audio")
        t.priority = Thread.MAX_PRIORITY
        thread = t
        t.start()
    }

    fun pause() {
        if (!playing) return
        val t = currentTimeSec()
        stopThread()
        pausedAtSec = t
        playing = false
    }

    fun seekTo(sec: Double) {
        val p = pcm ?: return
        val s = sec.coerceIn(0.0, p.durationSec)
        pausedAtSec = s
        if (playing) play(s)
    }

    fun release() {
        stopThread()
        playing = false
        irExecutor.shutdownNow()
    }

    private fun stopThread() {
        runFlag = false
        val t = thread
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(1500) } catch (e: InterruptedException) { }
        }
        thread = null
    }

    /** Posisi pemutaran yang benar-benar terdengar (detik). */
    fun currentTimeSec(): Double {
        val p = pcm ?: return 0.0
        if (!playing) return pausedAtSec
        val tr = trackRef ?: return (posAfterWrite / p.sampleRate).coerceIn(0.0, p.durationSec)
        val head = headFrames(tr)
        val pending = (framesWritten - head).coerceAtLeast(0L)
        val src = posAfterWrite - pending.toDouble() * rate
        return (src / p.sampleRate).coerceIn(0.0, p.durationSec)
    }

    private fun headFrames(tr: AudioTrack): Long {
        return try {
            tr.playbackHeadPosition.toLong() and 0xFFFFFFFFL
        } catch (e: Exception) {
            framesWritten
        }
    }

    /** Isi dest dengan sampel mono terbaru yang sedang terdengar. false jika tidak sedang memutar. */
    fun snapshot(dest: FloatArray): Boolean {
        if (!playing) return false
        val tr = trackRef ?: return false
        val head = headFrames(tr)
        val pending = (framesWritten - head).coerceIn(0L, (RING / 2).toLong())
        val endIdx = ringWrite - pending
        val startIdx = endIdx - dest.size
        for (i in dest.indices) {
            val idx = startIdx + i
            dest[i] = if (idx < 0L) 0f else ring[(idx and RING_MASK).toInt()]
        }
        return true
    }

    // ---------------------------------------------------------------- thread audio
    private fun runLoop(p: PcmData, startPos: Double) {
        val sr = p.sampleRate
        val block = PartitionedConvolver.BLOCK
        var track: AudioTrack? = null
        var ended = false
        var errorMsg: String? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            val bufBytes = maxOf(minBuf, block * 2 * 4 * 3)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            trackRef = track

            val chain = DspChain(sr)
            val outL = FloatArray(block)
            val outR = FloatArray(block)
            val inter = FloatArray(block * 2)
            var pos = startPos
            var vol = if (muted) 0f else volume

            track.play()
            while (runFlag) {
                val params = DspParams(rate, reverbOn, wet, spatialMode, intensity, speed)
                val tNow = System.currentTimeMillis() / 1000.0
                val newPos = chain.renderBlock(p, pos, params, convolver, looping, tNow, outL, outR)
                val valid = chain.validFrames

                val vTarget = if (muted) 0f else volume
                for (i in 0 until block) {
                    val l = outL[i]
                    val r = outR[i]
                    ring[((ringWrite + i.toLong()) and RING_MASK).toInt()] = (l + r) * 0.5f
                    val g = vol + (vTarget - vol) * ((i + 1).toFloat() / block.toFloat())
                    inter[2 * i] = clamp1(l * g)
                    inter[2 * i + 1] = clamp1(r * g)
                }
                ringWrite += block.toLong()
                vol = vTarget

                val n = if (valid < block) valid else block
                if (n > 0) {
                    val w = track.write(inter, 0, n * 2, AudioTrack.WRITE_BLOCKING)
                    if (w < 0) break
                    framesWritten += n.toLong()
                }
                pos = newPos
                posAfterWrite = pos
                if (valid < block) {
                    ended = true
                    break
                }
            }
        } catch (e: Throwable) {
            errorMsg = e.message ?: "Gagal memutar audio"
        } finally {
            val tr = track
            if (tr != null) {
                try {
                    if (ended) {
                        tr.stop()
                        val deadline = SystemClock.elapsedRealtime() + 1200
                        while (headFrames(tr) < framesWritten && SystemClock.elapsedRealtime() < deadline) {
                            Thread.sleep(10)
                        }
                    } else {
                        tr.pause()
                        tr.flush()
                    }
                } catch (e: Throwable) { }
                try { tr.release() } catch (e: Throwable) { }
            }
            trackRef = null
        }

        if (ended && runFlag) {
            runFlag = false
            playing = false
            pausedAtSec = 0.0
            mainHandler.post { onEnded?.invoke() }
        } else if (errorMsg != null && runFlag) {
            runFlag = false
            playing = false
            val msg: String = errorMsg
            mainHandler.post { onError?.invoke(msg) }
        }
    }

    private fun clamp1(v: Float): Float {
        return if (v > 1f) 1f else if (v < -1f) -1f else v
    }
}
