package com.audionce.studio.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Spesifikasi video: drawFrame menggambar frame ke-N pada canvas. */
class VideoSpec(
    val width: Int,
    val height: Int,
    val fps: Int,
    val drawFrame: (Int, Canvas) -> Unit
)

private class PendingSample(val track: Int, val data: ByteArray, val ptsUs: Long, val flags: Int)

/**
 * Mengenkode audio (AAC) dan, jika video != null, video H.264 lalu memuxnya ke MP4/M4A.
 * Dijalankan lebih cepat dari waktu nyata (offline), timestamp ditentukan eksplisit.
 */
object MediaExporter {

    fun export(
        pcm: ShortArray,
        frames: Int,
        sampleRate: Int,
        audioBitrate: Int,
        video: VideoSpec?,
        fd: FileDescriptor,
        onProgress: (Float) -> Unit
    ) {
        val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 2)
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, audioBitrate)
        audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
        val aEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        aEnc.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        aEnc.start()

        var vEnc: MediaCodec? = null
        var bitmap: Bitmap? = null
        var canvas: Canvas? = null
        var argb = IntArray(0)
        var rowTmp = ByteArray(0)
        if (video != null) {
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, video.width, video.height)
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            vf.setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, video.fps)
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            vEnc = enc
            val bmp = Bitmap.createBitmap(video.width, video.height, Bitmap.Config.ARGB_8888)
            bitmap = bmp
            canvas = Canvas(bmp)
            argb = IntArray(video.width * video.height)
            rowTmp = ByteArray(video.width)
        }

        val totalVideoFrames = if (video != null) {
            Math.ceil(frames.toDouble() / sampleRate.toDouble() * video.fps).toInt()
        } else {
            0
        }

        var audioTrack = -1
        var videoTrack = -1
        var muxerStarted = false
        var audioInputDone = false
        var videoInputDone = video == null
        var audioDone = false
        var videoDone = video == null
        var audioFed = 0
        var videoIndex = 0
        val pending = ArrayList<PendingSample>()
        val aInfo = MediaCodec.BufferInfo()
        val vInfo = MediaCodec.BufferInfo()

        fun maybeStart() {
            if (!muxerStarted && audioTrack >= 0 && (video == null || videoTrack >= 0)) {
                muxer.start()
                muxerStarted = true
                for (p in pending) {
                    val bi = MediaCodec.BufferInfo()
                    bi.set(0, p.data.size, p.ptsUs, p.flags)
                    muxer.writeSampleData(p.track, ByteBuffer.wrap(p.data), bi)
                }
                pending.clear()
            }
        }

        try {
            while (!(audioDone && videoDone)) {
                var progressed = false

                // ---- umpan frame video
                val ve = vEnc
                if (video != null && ve != null && !videoInputDone) {
                    val idx = ve.dequeueInputBuffer(0)
                    if (idx >= 0) {
                        val ptsUs = videoIndex.toLong() * 1_000_000L / video.fps.toLong()
                        if (videoIndex >= totalVideoFrames) {
                            ve.queueInputBuffer(idx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            videoInputDone = true
                        } else {
                            video.drawFrame(videoIndex, canvas!!)
                            bitmap!!.getPixels(argb, 0, video.width, 0, 0, video.width, video.height)
                            val image = ve.getInputImage(idx) ?: throw IllegalStateException("Encoder video tidak mendukung input Image")
                            fillImage(image, argb, video.width, video.height, rowTmp)
                            ve.queueInputBuffer(idx, 0, video.width * video.height * 3 / 2, ptsUs, 0)
                            videoIndex++
                        }
                        progressed = true
                    }
                }

                // ---- umpan audio (dibatasi agar tidak jauh mendahului video)
                if (!audioInputDone) {
                    val audioPts = audioFed.toLong() * 1_000_000L / sampleRate.toLong()
                    val videoPts = if (video != null) videoIndex.toLong() * 1_000_000L / video.fps.toLong() else 0L
                    val gate = video == null || videoInputDone || audioPts <= videoPts + 500_000L
                    if (gate) {
                        val idx = aEnc.dequeueInputBuffer(0)
                        if (idx >= 0) {
                            val buf = aEnc.getInputBuffer(idx)
                            if (buf != null) {
                                buf.clear()
                                val left = frames - audioFed
                                if (left <= 0) {
                                    aEnc.queueInputBuffer(idx, 0, 0, audioPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    audioInputDone = true
                                } else {
                                    val n = Math.min(left, buf.capacity() / 4)
                                    buf.order(ByteOrder.LITTLE_ENDIAN)
                                    val sb = buf.asShortBuffer()
                                    sb.put(pcm, audioFed * 2, n * 2)
                                    aEnc.queueInputBuffer(idx, 0, n * 4, audioPts, 0)
                                    audioFed += n
                                }
                                progressed = true
                            }
                        }
                    }
                }

                // ---- ambil hasil encode audio
                while (true) {
                    val oi = aEnc.dequeueOutputBuffer(aInfo, 0)
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) break
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        audioTrack = muxer.addTrack(aEnc.outputFormat)
                        maybeStart()
                        progressed = true
                    } else if (oi >= 0) {
                        val ob = aEnc.getOutputBuffer(oi)
                        if ((aInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) aInfo.size = 0
                        if (aInfo.size > 0 && ob != null) {
                            ob.position(aInfo.offset)
                            ob.limit(aInfo.offset + aInfo.size)
                            if (muxerStarted) {
                                muxer.writeSampleData(audioTrack, ob, aInfo)
                            } else {
                                val bytes = ByteArray(aInfo.size)
                                ob.get(bytes)
                                pending.add(PendingSample(audioTrack, bytes, aInfo.presentationTimeUs, aInfo.flags))
                            }
                        }
                        aEnc.releaseOutputBuffer(oi, false)
                        progressed = true
                        if ((aInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            audioDone = true
                            break
                        }
                    }
                }

                // ---- ambil hasil encode video
                if (ve != null && !videoDone) {
                    while (true) {
                        val oi = ve.dequeueOutputBuffer(vInfo, 0)
                        if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) break
                        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            videoTrack = muxer.addTrack(ve.outputFormat)
                            maybeStart()
                            progressed = true
                        } else if (oi >= 0) {
                            val ob = ve.getOutputBuffer(oi)
                            if ((vInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) vInfo.size = 0
                            if (vInfo.size > 0 && ob != null) {
                                ob.position(vInfo.offset)
                                ob.limit(vInfo.offset + vInfo.size)
                                if (muxerStarted) {
                                    muxer.writeSampleData(videoTrack, ob, vInfo)
                                } else {
                                    val bytes = ByteArray(vInfo.size)
                                    ob.get(bytes)
                                    pending.add(PendingSample(videoTrack, bytes, vInfo.presentationTimeUs, vInfo.flags))
                                }
                            }
                            ve.releaseOutputBuffer(oi, false)
                            progressed = true
                            if ((vInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                videoDone = true
                                break
                            }
                        }
                    }
                }

                val prog = if (video != null && totalVideoFrames > 0) {
                    videoIndex.toFloat() / totalVideoFrames.toFloat()
                } else {
                    audioFed.toFloat() / frames.toFloat()
                }
                onProgress(Math.min(1f, prog))

                if (!progressed) Thread.sleep(2)
            }
        } finally {
            try { aEnc.stop() } catch (e: Exception) { }
            aEnc.release()
            val ve2 = vEnc
            if (ve2 != null) {
                try { ve2.stop() } catch (e: Exception) { }
                ve2.release()
            }
            if (muxerStarted) {
                try { muxer.stop() } catch (e: Exception) { }
            }
            muxer.release()
            bitmap?.recycle()
        }
    }

    /** Menyalin ARGB ke Image YUV420 milik encoder (BT.601). */
    private fun fillImage(image: Image, argb: IntArray, w: Int, h: Int, rowTmp: ByteArray) {
        val planes = image.planes
        val yBuf = planes[0].buffer
        val yRs = planes[0].rowStride
        val yPs = planes[0].pixelStride
        val uBuf = planes[1].buffer
        val uRs = planes[1].rowStride
        val uPs = planes[1].pixelStride
        val vBuf = planes[2].buffer
        val vRs = planes[2].rowStride
        val vPs = planes[2].pixelStride

        for (j in 0 until h) {
            val src = j * w
            if (yPs == 1) {
                for (i in 0 until w) {
                    val c = argb[src + i]
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    rowTmp[i] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte()
                }
                yBuf.position(j * yRs)
                yBuf.put(rowTmp, 0, w)
            } else {
                for (i in 0 until w) {
                    val c = argb[src + i]
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    yBuf.put(j * yRs + i * yPs, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
                }
            }
        }

        for (j in 0 until h / 2) {
            for (i in 0 until w / 2) {
                val p0 = argb[(2 * j) * w + 2 * i]
                val p1 = argb[(2 * j) * w + 2 * i + 1]
                val p2 = argb[(2 * j + 1) * w + 2 * i]
                val p3 = argb[(2 * j + 1) * w + 2 * i + 1]
                val r = (((p0 shr 16) and 255) + ((p1 shr 16) and 255) + ((p2 shr 16) and 255) + ((p3 shr 16) and 255)) shr 2
                val g = (((p0 shr 8) and 255) + ((p1 shr 8) and 255) + ((p2 shr 8) and 255) + ((p3 shr 8) and 255)) shr 2
                val b = ((p0 and 255) + (p1 and 255) + (p2 and 255) + (p3 and 255)) shr 2
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                uBuf.put(j * uRs + i * uPs, u.toByte())
                vBuf.put(j * vRs + i * vPs, v.toByte())
            }
        }
    }
}
