package com.audionce.studio

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.audionce.studio.audio.AudioDecoder
import com.audionce.studio.audio.PcmData
import com.audionce.studio.audio.PlayerEngine
import com.audionce.studio.export.MediaExporter
import com.audionce.studio.export.MediaSaver
import com.audionce.studio.export.OfflineRenderer
import com.audionce.studio.export.RenderedAudio
import com.audionce.studio.export.VideoFrameRenderer
import java.util.concurrent.Executors

/** Pusat status dan logika aplikasi (setara bagian JS pada versi HTML). */
class AppController(val app: Application) {

    companion object {
        const val TOAST_INFO = 0
        const val TOAST_OK = 1
        const val TOAST_ERROR = 2
        val VIS_MODES = listOf("WAVE CANDY", "BARS", "CIRCULAR")
    }

    val engine = PlayerEngine()
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val exportWorker = Executors.newSingleThreadExecutor()

    // dipasang oleh MainActivity
    var pickAudio: () -> Unit = {}
    var pickCover: () -> Unit = {}

    // ------------------------------------------------------------------ state UI
    var loaded by mutableStateOf(false)
    var loadingFile by mutableStateOf(false)
    var fileName by mutableStateOf("")
    var fileFormat by mutableStateOf("")
    var sampleRateKhz by mutableStateOf(0)
    var durationSec by mutableStateOf(0.0)

    var trackTitle by mutableStateOf("")
    var trackArtist by mutableStateOf("")
    var trackLabel by mutableStateOf("")
    var coverApplied by mutableStateOf<Bitmap?>(null)
    var coverPending by mutableStateOf<Bitmap?>(null)

    var isPlaying by mutableStateOf(false)
    var posSec by mutableStateOf(0.0)
    var looping by mutableStateOf(false)
    var muted by mutableStateOf(false)
    var volume by mutableStateOf(0.75f)

    var slowedOn by mutableStateOf(false)
    var slowedRate by mutableStateOf(0.75f)
    var reverbOn by mutableStateOf(false)
    var reverbWet by mutableStateOf(0.45f)
    var reverbSize by mutableStateOf(2.5f)
    var reverbDecay by mutableStateOf(0.7f)

    var spatialMode by mutableStateOf(0)
    var spatialIntensity by mutableStateOf(0.7f)
    var spatialSpeed by mutableStateOf(0.5f)

    var visMode by mutableStateOf(0)
    var visLabelNonce by mutableStateOf(0)

    var effectsOpen by mutableStateOf(false)
    var spatialOpen by mutableStateOf(false)
    var metadataOpen by mutableStateOf(false)
    var exportOpen by mutableStateOf(false)

    var metaTitle by mutableStateOf("")
    var metaArtist by mutableStateOf("")
    var metaLabel by mutableStateOf("")

    var exportVideo by mutableStateOf(false)
    var exportFormat by mutableStateOf("wav")
    var dlSlowed by mutableStateOf(false)
    var dlReverb by mutableStateOf(false)
    var dlSpatial by mutableStateOf(false)

    var toastMsg by mutableStateOf("")
    var toastKind by mutableStateOf(TOAST_INFO)
    var toastVisible by mutableStateOf(false)
    private var toastToken = 0

    var processing by mutableStateOf(false)
    var processingText by mutableStateOf("")
    var processingPercent by mutableStateOf(-1)

    private var pausedAt = 0.0

    init {
        engine.onEnded = {
            isPlaying = false
            pausedAt = 0.0
            posSec = 0.0
            PlaybackService.stop(app)
        }
        engine.onError = { msg ->
            isPlaying = false
            PlaybackService.stop(app)
            showToast(msg, TOAST_ERROR)
        }
    }

    // ------------------------------------------------------------------ tampilan teks
    fun displayTitle(): String {
        if (trackTitle.isNotEmpty()) return trackTitle
        return if (fileName.isNotEmpty()) fileName else "—"
    }

    fun displayDetails(): String {
        val parts = ArrayList<String>()
        if (trackArtist.isNotEmpty()) parts.add(trackArtist)
        if (trackLabel.isNotEmpty()) parts.add(trackLabel)
        parts.add(if (fileFormat.isNotEmpty()) fileFormat else "AUDIO")
        parts.add("${sampleRateKhz}kHz")
        parts.add(formatTime(durationSec))
        return parts.joinToString(" · ")
    }

    fun formatTime(s: Double): String {
        if (s.isNaN() || s < 0.0) return "0:00"
        val total = s.toInt()
        val m = total / 60
        val sec = total % 60
        return "$m:${sec.toString().padStart(2, '0')}"
    }

    fun badges(): List<String> {
        val list = ArrayList<String>()
        if (slowedOn) list.add("SLOWED ${formatRate(slowedRate)}×")
        if (reverbOn) list.add("REVERB")
        if (spatialMode != 0) list.add(spatialName(spatialMode))
        return list
    }

    fun formatRate(v: Float): String {
        // sama dengan nilai atribut value pada <input type=range>: 0.75, 0.7, 1
        val r = Math.round(v * 100f) / 100f
        return if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()
    }

    fun spatialName(mode: Int): String {
        return when (mode) {
            1 -> "3D"
            2 -> "8D"
            3 -> "10D"
            else -> "OFF"
        }
    }

    // ------------------------------------------------------------------ toast
    fun showToast(msg: String, kind: Int = TOAST_INFO) {
        toastMsg = msg
        toastKind = kind
        toastVisible = true
        toastToken++
        val tk = toastToken
        main.postDelayed({
            if (tk == toastToken) toastVisible = false
        }, 3000)
    }

    // ------------------------------------------------------------------ muat file
    fun loadFromUri(uri: Uri) {
        if (loadingFile) return
        loadingFile = true
        showToast("Loading…", TOAST_INFO)
        worker.execute {
            try {
                val rawName = queryName(uri)
                val pcm = AudioDecoder.decode(app, uri)
                val cover = readEmbeddedCover(uri)
                main.post { onLoaded(rawName, pcm, cover) }
            } catch (e: Throwable) {
                main.post {
                    loadingFile = false
                    showToast("Could not decode", TOAST_ERROR)
                }
            }
        }
    }

    private fun onLoaded(rawName: String, pcm: PcmData, cover: Bitmap?) {
        if (isPlaying) {
            engine.pause()
            isPlaying = false
            PlaybackService.stop(app)
        }
        val dot = rawName.lastIndexOf('.')
        fileName = if (dot > 0) rawName.substring(0, dot) else rawName
        fileFormat = if (dot > 0 && dot < rawName.length - 1) rawName.substring(dot + 1).uppercase() else "AUDIO"
        sampleRateKhz = Math.round(pcm.sampleRate / 1000.0).toInt()
        durationSec = pcm.durationSec
        trackTitle = ""
        trackArtist = ""
        trackLabel = ""
        coverApplied = cover
        coverPending = null
        pausedAt = 0.0
        posSec = 0.0

        pushEngineParams()
        engine.load(pcm)
        loaded = true
        loadingFile = false
        showToast("Loaded: $rawName", TOAST_OK)
    }

    private fun pushEngineParams() {
        engine.volume = volume
        engine.muted = muted
        engine.looping = looping
        engine.rate = if (slowedOn) slowedRate.toDouble() else 1.0
        engine.reverbOn = reverbOn
        engine.wet = reverbWet
        engine.roomSize = reverbSize
        engine.decay = reverbDecay
        engine.spatialMode = spatialMode
        engine.intensity = spatialIntensity
        engine.speed = spatialSpeed
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            val c = app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (c != null) {
                try {
                    if (c.moveToFirst()) name = c.getString(0)
                } finally {
                    c.close()
                }
            }
        } catch (e: Exception) {
        }
        val n = name
        if (n != null && n.isNotEmpty()) return n
        val last = uri.lastPathSegment
        return if (last != null && last.isNotEmpty()) last else "audio"
    }

    private fun readEmbeddedCover(uri: Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(app, uri)
            val bytes = r.embeddedPicture
            return if (bytes != null) decodeBitmap(bytes) else null
        } catch (e: Exception) {
            return null
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun decodeBitmap(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        val maxDim = Math.max(bounds.outWidth, bounds.outHeight)
        while (maxDim / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    // ------------------------------------------------------------------ pemutaran
    fun togglePlay() {
        if (!loaded) return
        if (isPlaying) pausePlayback() else resumePlayback()
    }

    private fun resumePlayback() {
        engine.play(pausedAt)
        isPlaying = true
        PlaybackService.start(app)
    }

    private fun pausePlayback() {
        engine.pause()
        pausedAt = engine.currentTimeSec()
        posSec = pausedAt
        isPlaying = false
        PlaybackService.stop(app)
    }

    fun refreshPosition() {
        if (!isPlaying) return
        val t = engine.currentTimeSec()
        if (Math.abs(t - posSec) > 0.02) posSec = t
    }

    fun skip(deltaSec: Double) {
        if (!loaded) return
        val ct = if (isPlaying) engine.currentTimeSec() else pausedAt
        val newT = if (deltaSec < 0) Math.max(0.0, ct + deltaSec) else Math.min(durationSec - 0.1, ct + deltaSec)
        seekTo(Math.max(0.0, newT))
    }

    fun seekFraction(f: Float) {
        if (!loaded) return
        seekTo(f.coerceIn(0f, 1f).toDouble() * durationSec)
    }

    private fun seekTo(t: Double) {
        pausedAt = t
        posSec = t
        engine.seekTo(t)
    }

    fun toggleLoop() {
        looping = !looping
        engine.looping = looping
        showToast(if (looping) "Loop on" else "Loop off")
    }

    fun toggleMute() {
        muted = !muted
        engine.muted = muted
    }

    fun setVolumeValue(v: Float) {
        volume = v
        engine.volume = v
    }

    fun cycleVisualizer() {
        visMode = (visMode + 1) % VIS_MODES.size
        visLabelNonce++
        showToast("Visualizer: ${VIS_MODES[visMode]}")
    }

    // ------------------------------------------------------------------ efek
    fun setSlowedOn(on: Boolean) {
        slowedOn = on
        engine.rate = if (on) slowedRate.toDouble() else 1.0
    }

    fun setSlowedRate(v: Float) {
        slowedRate = v
        if (slowedOn) engine.rate = v.toDouble()
    }

    fun setReverbEnabled(on: Boolean) {
        reverbOn = on
        engine.reverbOn = on
    }

    fun setWet(v: Float) {
        reverbWet = v
        engine.wet = v
    }

    fun setRoom(v: Float) {
        reverbSize = v
        engine.roomSize = v
        engine.rebuildReverb()
    }

    fun setDecay(v: Float) {
        reverbDecay = v
        engine.decay = v
        engine.rebuildReverb()
    }

    fun setSpatial(mode: Int) {
        spatialMode = mode
        engine.spatialMode = mode
    }

    fun setIntensity(v: Float) {
        spatialIntensity = v
        engine.intensity = v
    }

    fun setSpeed(v: Float) {
        spatialSpeed = v
        engine.speed = v
    }

    // ------------------------------------------------------------------ metadata
    fun openMetadata() {
        metaTitle = if (trackTitle.isNotEmpty()) trackTitle else fileName
        metaArtist = trackArtist
        metaLabel = trackLabel
    }

    fun applyMetadata() {
        val t = metaTitle.trim()
        if (t.isNotEmpty()) trackTitle = t
        trackArtist = metaArtist.trim()
        trackLabel = metaLabel.trim()
        val pending = coverPending
        if (pending != null) coverApplied = pending
        showToast("Metadata diperbarui", TOAST_OK)
    }

    fun resetMetadata() {
        trackTitle = ""
        trackArtist = ""
        trackLabel = ""
        metaTitle = ""
        metaArtist = ""
        metaLabel = ""
        showToast("Metadata direset")
    }

    fun setCoverFromUri(uri: Uri) {
        worker.execute {
            try {
                val stream = app.contentResolver.openInputStream(uri)
                val bytes = stream?.use { it.readBytes() }
                val bmp = if (bytes != null) decodeBitmap(bytes) else null
                main.post {
                    if (bmp != null) coverPending = bmp else showToast("Gambar tidak bisa dibaca", TOAST_ERROR)
                }
            } catch (e: Throwable) {
                main.post { showToast("Gambar tidak bisa dibaca", TOAST_ERROR) }
            }
        }
    }

    // ------------------------------------------------------------------ export
    private fun setProgress(text: String, fraction: Float) {
        val pct = Math.round(fraction.coerceIn(0f, 1f) * 100f)
        main.post {
            processingText = text
            processingPercent = pct
        }
    }

    fun startExport() {
        val pcm = engine.pcm
        if (pcm == null) {
            showToast("Belum ada audio yang dimuat", TOAST_ERROR)
            return
        }
        if (processing) return

        val video = exportVideo
        val format = exportFormat
        val inclSlowed = dlSlowed && slowedOn
        val inclReverb = dlReverb && reverbOn
        val inclSpatial = dlSpatial && spatialMode != 0
        val rate = if (inclSlowed) slowedRate.toDouble() else 1.0
        val wet = reverbWet
        val size = reverbSize
        val decay = reverbDecay
        val sMode = if (inclSpatial) spatialMode else 0
        val inten = spatialIntensity
        val spd = spatialSpeed
        val baseName = sanitizeName(if (trackTitle.isNotEmpty()) trackTitle else if (fileName.isNotEmpty()) fileName else "audionce-export")
        val titleText = displayTitle()
        val artistText = trackArtist
        val fmtText = if (fileFormat.isNotEmpty()) fileFormat else "AUDIO"
        val cover = coverPending ?: coverApplied

        processing = true
        processingPercent = 0
        processingText = if (video) "Menyiapkan video export…" else "Merender audio…"

        exportWorker.execute {
            var uri: Uri? = null
            try {
                val renderShare = if (video) 0.15f else 0.5f
                val rendered: RenderedAudio = OfflineRenderer.render(
                    pcm, rate, inclReverb, wet, size, decay, sMode, inten, spd
                ) { p -> setProgress("Merender audio…", p * renderShare) }

                if (video) {
                    val out = MediaSaver.createUri(app, "$baseName.mp4", "video/mp4", true)
                        ?: throw IllegalStateException("Tidak bisa membuat file video")
                    uri = out
                    val pfd = app.contentResolver.openFileDescriptor(out, "rw")
                        ?: throw IllegalStateException("Tidak bisa membuka file video")
                    try {
                        val renderer = VideoFrameRenderer(rendered, cover, titleText, artistText, fmtText)
                        MediaExporter.export(
                            rendered.samples, rendered.frames, rendered.sampleRate, 320000,
                            renderer.spec(), pfd.fileDescriptor
                        ) { p -> setProgress("Merekam video…", renderShare + p * (1f - renderShare)) }
                    } finally {
                        pfd.close()
                    }
                    MediaSaver.finish(app, out)
                    postDone("Video berhasil: $baseName.mp4 (Movies/Audionce)")
                } else if (format == "m4a") {
                    val out = MediaSaver.createUri(app, "$baseName.m4a", "audio/mp4", false)
                        ?: throw IllegalStateException("Tidak bisa membuat file audio")
                    uri = out
                    val pfd = app.contentResolver.openFileDescriptor(out, "rw")
                        ?: throw IllegalStateException("Tidak bisa membuka file audio")
                    try {
                        MediaExporter.export(
                            rendered.samples, rendered.frames, rendered.sampleRate, 192000,
                            null, pfd.fileDescriptor
                        ) { p -> setProgress("Mengenkode M4A…", renderShare + p * (1f - renderShare)) }
                    } finally {
                        pfd.close()
                    }
                    MediaSaver.finish(app, out)
                    postDone("M4A berhasil: $baseName.m4a (Music/Audionce)")
                } else {
                    val out = MediaSaver.createUri(app, "$baseName.wav", "audio/x-wav", false)
                        ?: throw IllegalStateException("Tidak bisa membuat file audio")
                    uri = out
                    MediaSaver.writeWav(app, out, rendered) { p ->
                        setProgress("Mengenkode WAV…", renderShare + p * (1f - renderShare))
                    }
                    MediaSaver.finish(app, out)
                    postDone("WAV berhasil: $baseName.wav (Music/Audionce)")
                }
            } catch (e: Throwable) {
                val u = uri
                if (u != null) MediaSaver.discard(app, u)
                val msg = e.message ?: e.javaClass.simpleName
                main.post {
                    processing = false
                    showToast("Export gagal: $msg", TOAST_ERROR)
                }
            }
        }
    }

    private fun postDone(msg: String) {
        main.post {
            processing = false
            showToast(msg, TOAST_OK)
        }
    }

    private fun sanitizeName(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (cleaned.isEmpty()) "audionce-export" else cleaned
    }
}
