package com.audionce.studio.audio

import java.util.Random

/** Pembangkit impulse response, sama dengan generateIR() pada versi HTML. */
object ReverbIr {
    fun generate(sampleRate: Int, duration: Float, decay: Float, earlyTaps: Boolean): Array<FloatArray> {
        val length = Math.floor(sampleRate * duration.toDouble()).toInt()
        val rnd = Random()
        val expo = decay * 3.0 + 2.0
        val tapDelays = doubleArrayOf(0.011, 0.027, 0.041, 0.071)
        val tapGains = floatArrayOf(0.7f, 0.5f, 0.35f, 0.25f)
        val tapIdx = IntArray(4) { Math.floor(tapDelays[it] * sampleRate).toInt() }
        return Array(2) {
            val data = FloatArray(length)
            for (i in 0 until length) {
                val t = i.toDouble() / length.toDouble()
                val env = Math.pow(1.0 - t, expo).toFloat()
                var s = (rnd.nextFloat() * 2f - 1f) * env
                if (earlyTaps) {
                    for (k in 0 until 4) {
                        if (i < tapIdx[k]) s += (rnd.nextFloat() * 2f - 1f) * tapGains[k]
                    }
                }
                data[i] = s * 1.2f
            }
            data
        }
    }
}

/**
 * Konvolusi FFT berpartisi (uniform partitioned overlap-save), stereo (L*IR_L, R*IR_R),
 * dengan normalisasi seperti ConvolverNode pada Web Audio.
 */
class PartitionedConvolver(ir: Array<FloatArray>, sampleRate: Int, normalize: Boolean) {
    companion object {
        const val BLOCK = 2048
    }

    private val b = BLOCK
    private val n = BLOCK * 2
    private val bins = BLOCK + 1
    private val fft = Fft(n)
    private val parts: Int = (ir[0].size + BLOCK - 1) / BLOCK
    private val hRe: Array<FloatArray> = Array(2) { FloatArray(parts * bins) }
    private val hIm: Array<FloatArray> = Array(2) { FloatArray(parts * bins) }
    private val fRe: Array<FloatArray> = Array(2) { FloatArray(parts * bins) }
    private val fIm: Array<FloatArray> = Array(2) { FloatArray(parts * bins) }
    private val prev: Array<FloatArray> = Array(2) { FloatArray(BLOCK) }
    private val bufRe = FloatArray(n)
    private val bufIm = FloatArray(n)
    private val accRe = FloatArray(bins)
    private val accIm = FloatArray(bins)
    private var pos = 0

    init {
        val scale = computeScale(ir, sampleRate, normalize)
        for (ch in 0 until 2) {
            val src = ir[ch]
            for (p in 0 until parts) {
                java.util.Arrays.fill(bufRe, 0f)
                java.util.Arrays.fill(bufIm, 0f)
                val start = p * b
                val cnt = minOf(b, src.size - start)
                for (i in 0 until cnt) bufRe[i] = src[start + i] * scale
                fft.transform(bufRe, bufIm, false)
                System.arraycopy(bufRe, 0, hRe[ch], p * bins, bins)
                System.arraycopy(bufIm, 0, hIm[ch], p * bins, bins)
            }
        }
    }

    private fun computeScale(ir: Array<FloatArray>, sampleRate: Int, normalize: Boolean): Float {
        if (!normalize) return 1f
        var sum = 0.0
        for (ch in ir) {
            for (v in ch) sum += (v * v).toDouble()
        }
        var power = Math.sqrt(sum / (ir.size * ir[0].size).toDouble())
        if (power.isNaN() || power.isInfinite() || power < 0.000125) power = 0.000125
        var scale = 1.0 / power
        scale *= Math.pow(10.0, -58.0 * 0.05)
        scale *= 44100.0 / sampleRate.toDouble()
        return scale.toFloat()
    }

    fun reset() {
        for (ch in 0 until 2) {
            java.util.Arrays.fill(fRe[ch], 0f)
            java.util.Arrays.fill(fIm[ch], 0f)
            java.util.Arrays.fill(prev[ch], 0f)
        }
        pos = 0
    }

    /** Memproses satu blok (BLOCK sampel) per kanal. */
    fun process(inL: FloatArray, inR: FloatArray, outL: FloatArray, outR: FloatArray) {
        pos = if (pos == 0) parts - 1 else pos - 1
        for (ch in 0 until 2) {
            val input = if (ch == 0) inL else inR
            val output = if (ch == 0) outL else outR
            val pv = prev[ch]
            System.arraycopy(pv, 0, bufRe, 0, b)
            System.arraycopy(input, 0, bufRe, b, b)
            java.util.Arrays.fill(bufIm, 0f)
            fft.transform(bufRe, bufIm, false)

            val fr = fRe[ch]
            val fi = fIm[ch]
            val base = pos * bins
            System.arraycopy(bufRe, 0, fr, base, bins)
            System.arraycopy(bufIm, 0, fi, base, bins)
            System.arraycopy(input, 0, pv, 0, b)

            java.util.Arrays.fill(accRe, 0f)
            java.util.Arrays.fill(accIm, 0f)
            val hr = hRe[ch]
            val hi = hIm[ch]
            var idx = pos
            for (k in 0 until parts) {
                val hb = k * bins
                val fb = idx * bins
                for (i in 0 until bins) {
                    val a = hr[hb + i]
                    val bq = hi[hb + i]
                    val c = fr[fb + i]
                    val d = fi[fb + i]
                    accRe[i] += a * c - bq * d
                    accIm[i] += a * d + bq * c
                }
                idx++
                if (idx == parts) idx = 0
            }

            for (i in 0 until bins) {
                bufRe[i] = accRe[i]
                bufIm[i] = accIm[i]
            }
            for (i in 1 until b) {
                bufRe[n - i] = accRe[i]
                bufIm[n - i] = -accIm[i]
            }
            fft.transform(bufRe, bufIm, true)
            System.arraycopy(bufRe, b, output, 0, b)
        }
    }
}
