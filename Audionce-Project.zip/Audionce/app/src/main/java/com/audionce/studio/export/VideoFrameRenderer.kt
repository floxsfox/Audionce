package com.audionce.studio.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.audionce.studio.vis.WaveCandyEngine

/** Menggambar frame video export (1280x720): cover art, judul, Wave Candy (sama dengan renderFrame() di HTML). */
class VideoFrameRenderer(
    private val audio: RenderedAudio,
    private val cover: Bitmap?,
    private val title: String,
    private val artist: String,
    private val format: String
) {
    private val vw = 1280
    private val vh = 720
    private val fps = 50

    private val engine = WaveCandyEngine(0.2f)
    private val window = FloatArray(8192)
    private val lines = FloatArray(4 * 1300)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.SQUARE
        strokeWidth = 2.5f
        color = 0xFFFF3344.toInt()
    }
    private val glow1 = RadialGradient(vw * 0.25f, vh * 0.25f, vw * 0.45f, 0x1206B6D4, 0x0006B6D4, Shader.TileMode.CLAMP)
    private val glow2 = RadialGradient(vw * 0.75f, vh * 0.75f, vw * 0.45f, 0x0F8B5CF6, 0x008B5CF6, Shader.TileMode.CLAMP)
    private val glowPaint = Paint()

    fun spec(): VideoSpec = VideoSpec(vw, vh, fps) { index, canvas -> draw(index, canvas) }

    private fun roundRectPath(x: Float, y: Float, w: Float, h: Float, r: Float): Path {
        val p = Path()
        p.addRoundRect(RectF(x, y, x + w, y + h), r, r, Path.Direction.CW)
        return p
    }

    private fun fillWindow(frameIndex: Int) {
        val endFrame = Math.floor(frameIndex.toDouble() / fps * audio.sampleRate).toInt()
        val start = endFrame - window.size
        for (i in window.indices) {
            val f = start + i
            if (f < 0 || f >= audio.frames) {
                window[i] = 0f
            } else {
                val l = audio.samples[f * 2].toInt()
                val r = audio.samples[f * 2 + 1].toInt()
                window[i] = (l + r) * 0.5f / 32768f
            }
        }
    }

    private fun draw(frameIndex: Int, c: Canvas) {
        // latar
        fill.shader = null
        fill.color = 0xFF0A0A0B.toInt()
        c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), fill)
        glowPaint.shader = glow1
        c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), glowPaint)
        glowPaint.shader = glow2
        c.drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), glowPaint)

        // cover art
        val artSize = 260f
        val artX = 70f
        val artY = (vh - artSize) / 2f
        val artPath = roundRectPath(artX, artY, artSize, artSize, 14f)
        if (cover != null) {
            c.save()
            c.clipPath(artPath)
            c.drawBitmap(cover, null, RectF(artX, artY, artX + artSize, artY + artSize), fill)
            c.restore()
            stroke.color = 0x738B5CF6
            stroke.strokeWidth = 2f
            c.drawPath(artPath, stroke)
        } else {
            fill.color = 0xFF18181B.toInt()
            c.drawPath(artPath, fill)
            stroke.color = 0xFF28282E.toInt()
            stroke.strokeWidth = 2f
            c.drawPath(artPath, stroke)
            text.typeface = Typeface.MONOSPACE
            text.textSize = 40f
            text.color = 0xFF28282E.toInt()
            text.textAlign = Paint.Align.CENTER
            c.drawText("\u266A", artX + artSize / 2f, artY + artSize / 2f + 14f, text)
            text.textAlign = Paint.Align.LEFT
        }

        // teks
        val textX = artX + artSize + 54f
        val textW = vw - textX - 60f
        text.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        text.textSize = 38f
        text.color = 0xFFEDEEF0.toInt()
        var name = title
        while (text.measureText(name) > textW && name.length > 8) {
            name = name.substring(0, name.length - 4) + "\u2026"
        }
        c.drawText(name, textX, vh / 2f - 80f, text)

        if (artist.isNotEmpty()) {
            text.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            text.textSize = 22f
            text.color = 0xFF9A9BA3.toInt()
            c.drawText(artist, textX, vh / 2f - 40f, text)
        }

        text.typeface = Typeface.MONOSPACE
        text.textSize = 15f
        text.color = 0xFF5A5B64.toInt()
        val fmtY = vh / 2f - (if (artist.isNotEmpty()) 8f else 38f)
        c.drawText("$format \u00B7 AUDIONCE STUDIO", textX, fmtY, text)

        stroke.color = 0xFF28282E.toInt()
        stroke.strokeWidth = 1f
        c.drawLine(textX, vh / 2f + 4f, textX + textW, vh / 2f + 4f, stroke)

        // Wave Candy
        fillWindow(frameIndex)
        val visY = vh / 2f + 20f
        val visH = 140f
        val midVis = visY + visH / 2f
        val pts = Math.min(800, Math.floor(textW.toDouble()).toInt())
        val count = engine.buildLines(window, textX, midVis, textW, visH / 2f, pts, lines)
        c.drawLines(lines, 0, count, wavePaint)

        stroke.color = 0x24FF3344
        stroke.strokeWidth = 1f
        c.drawLine(textX, midVis, textX + textW, midVis, stroke)

        // watermark
        text.typeface = Typeface.MONOSPACE
        text.textSize = 12f
        text.color = 0xCC2A2A30.toInt()
        c.drawText("AUDIONCE STUDIO \u00B7 WAVE CANDY EDITION", 70f, vh - 28f, text)
    }
}
