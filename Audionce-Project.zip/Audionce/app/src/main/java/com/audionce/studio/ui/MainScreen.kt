package com.audionce.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.audionce.studio.AppController
import kotlinx.coroutines.delay
import java.util.Locale

private val ArtPlaceholder = IconSpec(emptyList(), listOf(floatArrayOf(12f, 12f, 4f), floatArrayOf(12f, 12f, 9f)), false)

private fun fmt(v: Float, digits: Int): String = String.format(Locale.US, "%." + digits + "f", v)

@Composable
fun MainScreen(c: AppController) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Pal.bg)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color(0x1006B6D4), Color.Transparent),
                        center = Offset(size.width * 0.3f, size.height * 0.2f),
                        radius = size.width * 0.9f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color(0x0D8B5CF6), Color.Transparent),
                        center = Offset(size.width * 0.7f, size.height * 0.7f),
                        radius = size.width * 1.0f
                    )
                )
            }
            .systemBarsPadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Header(c)
                if (!c.loaded) {
                    Welcome(c)
                } else {
                    PlayerCard(c)
                    Toolbar(c)
                    if (c.effectsOpen) EffectsPanel(c)
                    if (c.metadataOpen) MetadataPanel(c)
                    if (c.spatialOpen) SpatialPanel(c)
                    if (c.exportOpen) ExportPanel(c)
                }
                Box(Modifier.fillMaxWidth().padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    T("AUDIONCE \u00B7 FL STUDIO WAVE CANDY PRECISION", 10f, Pal.muted, mono = true, spacing = 2f, align = TextAlign.Center)
                }
            }
        }
        ToastView(c)
        if (c.processing) ProcessingOverlay(c)
    }
}

// ---------------------------------------------------------------------------- header
@Composable
private fun Header(c: AppController) {
    Row(
        Modifier.fillMaxWidth().padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(AccentBrush),
                contentAlignment = Alignment.Center
            ) {
                SvgIcon(Icons.music, 20.dp, Color.White)
            }
            Column {
                T("Audionce", 22f, weight = FontWeight.SemiBold, brush = AccentBrush)
                T("WAVE CANDY EDITION", 9.5f, Pal.muted, mono = true, spacing = 3f)
            }
        }
        if (c.loaded) {
            val shape = RoundedCornerShape(8.dp)
            Row(
                Modifier
                    .clip(shape)
                    .background(Pal.surface2)
                    .border(1.dp, Pal.border2, shape)
                    .tap { c.pickAudio() }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SvgIcon(Icons.filePlus, 14.dp, Pal.dim)
                T("New File", 11f, Pal.dim, mono = true)
            }
        }
    }
}

// ---------------------------------------------------------------------------- welcome
@Composable
private fun Welcome(c: AppController) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.surface)
            .border(1.dp, Pal.border, shape)
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DashedCircle(Modifier.size(180.dp).clip(CircleShape).tap { c.pickAudio() }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                SvgIcon(Icons.upload, 44.dp, Pal.accent2.copy(alpha = 0.55f), 1.4f)
                Box(Modifier.height(8.dp))
                T(if (c.loadingFile) "Loading\u2026" else "Tap to choose", 14f, Pal.dim)
                Box(Modifier.height(4.dp))
                T("MP3 \u00B7 FLAC \u00B7 WAV", 10f, Pal.muted, mono = true, spacing = 2f)
            }
        }
        Box(Modifier.height(24.dp))
        T("Audionce Studio", 26f, weight = FontWeight.SemiBold, brush = AccentBrush)
        Box(Modifier.height(6.dp))
        T("FL Studio Wave Candy Precision", 14f, Pal.muted)
    }
}

// ---------------------------------------------------------------------------- player
@Composable
private fun PlayerCard(c: AppController) {
    val shape = RoundedCornerShape(20.dp)

    LaunchedEffect(c.isPlaying) {
        while (c.isPlaying) {
            c.refreshPosition()
            delay(50)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.surface)
            .border(1.dp, Pal.border, shape)
    ) {
        // info trek
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val artShape = RoundedCornerShape(12.dp)
            Box(
                Modifier.size(56.dp).clip(artShape).background(Pal.surface2).border(1.dp, Pal.border, artShape),
                contentAlignment = Alignment.Center
            ) {
                val bmp = c.coverApplied
                if (bmp != null) {
                    val img = remember(bmp) { bmp.asImageBitmap() }
                    Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    SvgIcon(ArtPlaceholder, 24.dp, Pal.muted, 1.5f)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                T(c.displayTitle(), 16f, weight = FontWeight.Medium, maxLines = 1)
                T(c.displayDetails(), 10.5f, Pal.muted, mono = true, maxLines = 2)
            }
            val badges = c.badges()
            if (badges.isNotEmpty()) {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (b in badges) Badge(b, true)
                }
            }
        }

        // visualizer
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.border))
        Box(
            Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(Color(0xFF0D0D0E))
                .tap { c.cycleVisualizer() }
        ) {
            VisualizerView(c, Modifier.fillMaxSize())
            VisLabel(c)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.border))

        // progres
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            val dur = c.durationSec
            val frac = if (dur > 0.0) (c.posSec / dur).toFloat() else 0f
            ProgressBar(frac) { c.seekFraction(it) }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                T(c.formatTime(c.posSec), 11f, Pal.muted, mono = true)
                T(c.formatTime(dur), 11f, Pal.muted, mono = true)
            }
        }

        // kontrol
        Column(
            Modifier.padding(start = 20.dp, end = 20.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SvgIcon(Icons.volume, 17.dp, Pal.muted)
                Box(Modifier.width(10.dp))
                NSlider(c.volume, { c.setVolumeValue(it) }, 0f, 1f, 0.01f, Modifier.width(150.dp))
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SquareButton(Icons.skipBack, false, { c.skip(-10.0) })
                SquareButton(Icons.back, false, { c.skip(-5.0) })
                Box(
                    Modifier
                        .size(56.dp)
                        .shadow(14.dp, CircleShape, ambientColor = Pal.accent2, spotColor = Pal.accent2)
                        .clip(CircleShape)
                        .background(AccentBrush)
                        .tap { c.togglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    SvgIcon(if (c.isPlaying) Icons.pause else Icons.play, 22.dp, Color.White)
                }
                SquareButton(Icons.next, false, { c.skip(5.0) })
                SquareButton(Icons.skipFwd, false, { c.skip(10.0) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SquareButton(Icons.loop, c.looping, { c.toggleLoop() }, 38.dp, 16.dp)
                SquareButton(Icons.mute, c.muted, { c.toggleMute() }, 38.dp, 16.dp)
            }
        }
    }
}

@Composable
private fun VisLabel(c: AppController) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(c.visLabelNonce) {
        if (c.visLabelNonce > 0) {
            show = true
            delay(1800)
            show = false
        }
    }
    if (show) {
        Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.TopEnd) {
            val shape = RoundedCornerShape(6.dp)
            Box(
                Modifier
                    .clip(shape)
                    .background(Color(0xF00D0D0E))
                    .border(1.dp, Pal.border2, shape)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                T(AppController.VIS_MODES[c.visMode] + " \u00B7 FL STUDIO", 10f, Pal.waveRed, mono = true, spacing = 1.5f)
            }
        }
    }
}

@Composable
private fun ProgressBar(frac: Float, onSeek: (Float) -> Unit) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    Box(
        Modifier
            .fillMaxWidth()
            .height(26.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(Unit) {
                detectTapGestures { off -> seek((off.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off -> dragFrac = (off.x / widthPx).coerceIn(0f, 1f) },
                    onDragEnd = {
                        val f = dragFrac
                        if (f != null) seek(f)
                        dragFrac = null
                    },
                    onDragCancel = { dragFrac = null }
                ) { change, _ ->
                    change.consume()
                    dragFrac = (change.position.x / widthPx).coerceIn(0f, 1f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val shown = dragFrac ?: frac
        Canvas(Modifier.fillMaxWidth().height(6.dp)) {
            val r = CornerRadius(size.height / 2f, size.height / 2f)
            drawRoundRect(color = Pal.surface3, cornerRadius = r)
            val fw = size.width * shown.coerceIn(0f, 1f)
            if (fw > 0f) {
                drawRoundRect(brush = AccentBrush, size = Size(fw, size.height), cornerRadius = r)
            }
        }
    }
}

// ---------------------------------------------------------------------------- toolbar & panel
@Composable
private fun Toolbar(c: AppController) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("Effects", Icons.effects, c.effectsOpen, { c.effectsOpen = !c.effectsOpen }, Modifier.weight(1f))
            OutlineButton("Spatial", Icons.spatial, c.spatialOpen, { c.spatialOpen = !c.spatialOpen }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("Metadata", Icons.edit, c.metadataOpen, {
                c.metadataOpen = !c.metadataOpen
                if (c.metadataOpen) c.openMetadata()
            }, Modifier.weight(1f))
            OutlineButton("Export", Icons.download, c.exportOpen, { c.exportOpen = !c.exportOpen }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun EffectGroup(
    icon: IconSpec,
    title: String,
    desc: String,
    on: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.surface2)
            .border(1.dp, Pal.border, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SvgIcon(icon, 18.dp, Pal.accent2)
                T(title, 15f, weight = FontWeight.Medium)
            }
            NToggle(on, onToggle)
        }
        T(desc, 12f, Pal.muted)
        content()
    }
}

@Composable
private fun EffectsPanel(c: AppController) {
    val active = c.slowedOn || c.reverbOn
    Panel("Audio Effects", if (active) "Active" else "Inactive", active) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            EffectGroup(Icons.clock, "Slowed", "Time-stretch with pitch preservation.", c.slowedOn, { c.setSlowedOn(!c.slowedOn) }) {
                SliderRow("Speed", c.slowedRate, fmt(c.slowedRate, 2) + "\u00D7", 0.5f, 1f, 0.05f) { c.setSlowedRate(it) }
            }
            EffectGroup(Icons.headphones, "Reverb", "Powerful convolution reverb.", c.reverbOn, { c.setReverbEnabled(!c.reverbOn) }) {
                SliderRow("Wet", c.reverbWet, Math.round(c.reverbWet * 100f).toString() + "%", 0f, 0.8f, 0.01f) { c.setWet(it) }
                SliderRow("Room", c.reverbSize, fmt(c.reverbSize, 1) + "s", 1f, 4.5f, 0.1f) { c.setRoom(it) }
                SliderRow("Decay", c.reverbDecay, fmt(c.reverbDecay, 2), 0.4f, 0.95f, 0.05f) { c.setDecay(it) }
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    T(text.uppercase(), 10f, Pal.muted, mono = true, spacing = 2f)
}

@Composable
private fun MetaField(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        FieldLabel(label)
        Box(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Pal.surface2)
                .border(1.dp, Pal.border2, shape)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Pal.text, fontSize = 15.sp),
                cursorBrush = SolidColor(Pal.accent2),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box {
                        if (value.isEmpty()) T(placeholder, 15f, Pal.muted)
                        inner()
                    }
                }
            )
        }
    }
}

@Composable
private fun MetadataPanel(c: AppController) {
    Panel("Edit Metadata", "Track Info", false) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FieldLabel("Cover Art")
                DashedBox(
                    Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)).background(Pal.surface2).tap { c.pickCover() },
                    10.dp
                ) {
                    val bmp = c.coverPending ?: c.coverApplied
                    if (bmp != null) {
                        val img = remember(bmp) { bmp.asImageBitmap() }
                        Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        T("CLICK\nTO UPLOAD\nIMAGE", 8.5f, Pal.muted, mono = true, align = TextAlign.Center, spacing = 1f)
                    }
                }
            }
            MetaField("Song Title", c.metaTitle, "Track name\u2026") { c.metaTitle = it }
            MetaField("Artist", c.metaArtist, "Artist name\u2026") { c.metaArtist = it }
            MetaField("Label / Publisher", c.metaLabel, "Label name\u2026") { c.metaLabel = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                GradientButton("Apply", Icons.checkCircle) { c.applyMetadata() }
                OutlineButton("Reset", Icons.trash, false, { c.resetMetadata() })
            }
        }
    }
}

@Composable
private fun SpatialBtn(label: String, desc: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) Pal.accentSoft else Pal.surface2)
            .border(1.dp, if (selected) Pal.accent2 else Pal.border2, shape)
            .tap(onClick)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        T(label, 14f, if (selected) Pal.accent2 else Pal.dim, mono = true, weight = FontWeight.Medium)
        T(desc, 10f, Pal.muted, mono = true)
    }
}

@Composable
private fun SpatialPanel(c: AppController) {
    val on = c.spatialMode != 0
    Panel("Spatial Audio", if (on) c.spatialName(c.spatialMode) else "Off", on) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            T("3D audio with binaural panning.", 12f, Pal.muted)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SpatialBtn("Off", "Stereo", c.spatialMode == 0, { c.setSpatial(0) }, Modifier.weight(1f))
                SpatialBtn("3D", "Surround", c.spatialMode == 1, { c.setSpatial(1) }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SpatialBtn("8D", "Rotating", c.spatialMode == 2, { c.setSpatial(2) }, Modifier.weight(1f))
                SpatialBtn("10D", "Enhanced", c.spatialMode == 3, { c.setSpatial(3) }, Modifier.weight(1f))
            }
            Column(Modifier.alpha(if (on) 1f else 0.4f).padding(top = 6.dp)) {
                SliderRow("Intensity", c.spatialIntensity, Math.round(c.spatialIntensity * 100f).toString() + "%", 0f, 1f, 0.05f, on) { c.setIntensity(it) }
                SliderRow("Speed", c.spatialSpeed, fmt(c.spatialSpeed, 1) + "\u00D7", 0.1f, 2f, 0.1f, on) { c.setSpeed(it) }
            }
        }
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, radio: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.tap(onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (radio) RadioDot(selected) else CheckBox(selected)
        T(label, 14f, Pal.text)
    }
}

@Composable
private fun ExportPanel(c: AppController) {
    Panel("Export Options", null, false) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FieldLabel("Type")
                ChoiceRow("Audio Only", !c.exportVideo, true) { c.exportVideo = false }
                ChoiceRow("Video (Wave Candy + Cover)", c.exportVideo, true) { c.exportVideo = true }
            }
            if (!c.exportVideo) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FieldLabel("Format")
                    ChoiceRow("WAV \u2014 Lossless PCM", c.exportFormat == "wav", true) { c.exportFormat = "wav" }
                    ChoiceRow("M4A \u2014 AAC 192 kbps", c.exportFormat == "m4a", true) { c.exportFormat = "m4a" }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FieldLabel("Video Spec")
                    T("1280 \u00D7 720 \u00B7 50fps \u00B7 Wave Candy \u00B7 Cover Art \u00B7 HD", 11f, Pal.muted, mono = true)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FieldLabel("Include Effects")
                ChoiceRow("Slowed", c.dlSlowed, false) { c.dlSlowed = !c.dlSlowed }
                ChoiceRow("Reverb", c.dlReverb, false) { c.dlReverb = !c.dlReverb }
                ChoiceRow("Spatial", c.dlSpatial, false) { c.dlSpatial = !c.dlSpatial }
            }
            Row { GradientButton("Export", Icons.download) { c.startExport() } }
            T(
                "Audio: WAV (offline render) \u00B7 M4A (AAC 192 kbps).\nVideo: Wave Candy + Cover Art \u00B7 1280\u00D7720 \u00B7 50fps \u00B7 MP4.\nHasil disimpan di Music/Audionce atau Movies/Audionce.",
                10.5f, Pal.muted, mono = true
            )
        }
    }
}

// ---------------------------------------------------------------------------- overlay
@Composable
private fun BoxScope.ToastView(c: AppController) {
    if (c.toastVisible) {
        val col = when (c.toastKind) {
            AppController.TOAST_OK -> Pal.green
            AppController.TOAST_ERROR -> Pal.red
            else -> Pal.dim
        }
        val icon = when (c.toastKind) {
            AppController.TOAST_OK -> Icons.checkCircle
            AppController.TOAST_ERROR -> Icons.xCircle
            else -> Icons.info
        }
        val shape = RoundedCornerShape(12.dp)
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp, start = 16.dp, end = 16.dp)
                .clip(shape)
                .background(Color(0xF2121214))
                .border(1.dp, col.copy(alpha = 0.6f), shape)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SvgIcon(icon, 16.dp, col)
            T(c.toastMsg, 13f, Pal.text, maxLines = 3, modifier = Modifier.widthIn(max = 300.dp))
        }
    }
}

@Composable
private fun Spinner() {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { angle = ((it / 4_000_000L) % 360L).toFloat() }
        }
    }
    Canvas(Modifier.size(38.dp)) {
        val sw = 3.dp.toPx()
        val tl = Offset(sw / 2f, sw / 2f)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(color = Pal.border2, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(width = sw))
        drawArc(color = Pal.accent2, startAngle = angle, sweepAngle = 100f, useCenter = false, topLeft = tl, size = sz, style = Stroke(width = sw, cap = StrokeCap.Round))
    }
}

@Composable
private fun ProcessingOverlay(c: AppController) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(shape)
                .background(Pal.surface)
                .border(1.dp, Pal.border2, shape)
                .padding(horizontal = 36.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spinner()
            T(c.processingText, 14f, Pal.text, align = TextAlign.Center)
            if (c.processingPercent >= 0) T(c.processingPercent.toString() + "%", 12f, Pal.accent2, mono = true)
            T("Please wait\u2026", 11f, Pal.muted, mono = true)
        }
    }
}
