package com.audionce.studio.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Decode file audio (MP3, FLAC, WAV, OGG, M4A, dll.) ke PCM 16-bit stereo memakai MediaCodec bawaan Android. */
object AudioDecoder {

    fun decode(context: Context, uri: Uri): PcmData {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var trackIndex = -1
        var inFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                trackIndex = i
                inFormat = f
                break
            }
        }
        if (trackIndex < 0 || inFormat == null) {
            extractor.release()
            throw IllegalStateException("Tidak ada trek audio di file ini")
        }
        extractor.selectTrack(trackIndex)

        val mime = inFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
        var sampleRate = if (inFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        var channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val durationUs = if (inFormat.containsKey(MediaFormat.KEY_DURATION)) inFormat.getLong(MediaFormat.KEY_DURATION) else 0L
        var pcmFloat = false

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(inFormat, null, null, 0)
        codec.start()

        val estFrames = (durationUs / 1_000_000.0 * sampleRate).toInt() + sampleRate
        var out = ShortArray(maxOf(1 shl 16, estFrames * 2))
        var outLen = 0

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)
                        if (ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.LITTLE_ENDIAN)
                            val ch = if (channels < 1) 2 else channels
                            if (pcmFloat) {
                                val fb = ob.asFloatBuffer()
                                val nFrames = fb.remaining() / ch
                                if (outLen + nFrames * 2 > out.size) out = out.copyOf(maxOf(out.size * 2, outLen + nFrames * 2))
                                for (f in 0 until nFrames) {
                                    val l = fb.get()
                                    val r = if (ch > 1) fb.get() else l
                                    for (x in 2 until ch) fb.get()
                                    out[outLen++] = toShort(l)
                                    out[outLen++] = toShort(r)
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                val nFrames = sb.remaining() / ch
                                if (outLen + nFrames * 2 > out.size) out = out.copyOf(maxOf(out.size * 2, outLen + nFrames * 2))
                                for (f in 0 until nFrames) {
                                    val l = sb.get()
                                    val r = if (ch > 1) sb.get() else l
                                    for (x in 2 until ch) sb.get()
                                    out[outLen++] = l
                                    out[outLen++] = r
                                }
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
        } finally {
            try { codec.stop() } catch (e: Exception) { }
            codec.release()
            extractor.release()
        }

        val frames = outLen / 2
        if (frames <= 0) throw IllegalStateException("Audio kosong atau format tidak didukung")
        return PcmData(out, frames, sampleRate)
    }

    private fun toShort(v: Float): Short {
        val x = (v * 32767f).toInt()
        return x.coerceIn(-32768, 32767).toShort()
    }
}
