package com.audionce.studio.ui

/** Ikon dari set Feather (sama dengan versi HTML). Path sudah dinormalkan. */
class IconSpec(val paths: List<String>, val circles: List<FloatArray>, val filled: Boolean)

object Icons {
    val music = IconSpec(listOf("M9 18V5l12 -2v13"), listOf(floatArrayOf(6f, 18f, 3f), floatArrayOf(18f, 16f, 3f)), false)
    val upload = IconSpec(listOf("M12 16V8M12 8L9.5 10.5M12 8L14.5 10.5", "M8 18h8"), listOf(), false)
    val play = IconSpec(listOf("M5 3l14 9 -14 9V3z"), listOf(), true)
    val pause = IconSpec(listOf("M7 5h3v14H7z", "M14 5h3v14h-3z"), listOf(), true)
    val skipBack = IconSpec(listOf("M12 5L5 12l7 7", "M19 5l-7 7 7 7"), listOf(), false)
    val back = IconSpec(listOf("M15 18L9 12l6 -6"), listOf(), false)
    val next = IconSpec(listOf("M9 18l6 -6 -6 -6"), listOf(), false)
    val skipFwd = IconSpec(listOf("M12 5l7 7 -7 7", "M5 5l7 7 -7 7"), listOf(), false)
    val loop = IconSpec(listOf("M17 1l4 4 -4 4", "M3 11V9a4 4 0 0 1 4 -4h14", "M7 23l-4 -4 4 -4", "M21 13v2a4 4 0 0 1 -4 4H3"), listOf(), false)
    val volume = IconSpec(listOf("M11 5L6 9H2v6h4l5 4V5z", "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"), listOf(), false)
    val mute = IconSpec(listOf("M11 5L6 9H2v6h4l5 4V5z"), listOf(), false)
    val effects = IconSpec(listOf("M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83 -2.83M16.95 7.05l2.83 -2.83"), listOf(floatArrayOf(12f, 12f, 3f)), false)
    val spatial = IconSpec(listOf("M21 16V8a2 2 0 0 0 -1 -1.73l-7 -4a2 2 0 0 0 -2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7 -4A2 2 0 0 0 21 16z"), listOf(), false)
    val edit = IconSpec(listOf("M11 4H4a2 2 0 0 0 -2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2 -2v-7", "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1 -4 9.5 -9.5z"), listOf(), false)
    val download = IconSpec(listOf("M21 15v4a2 2 0 0 1 -2 2H5a2 2 0 0 1 -2 -2v-4", "M7 10l5 5 5 -5", "M12 15V3"), listOf(), false)
    val filePlus = IconSpec(listOf("M14 2H6a2 2 0 0 0 -2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2V8z", "M14 2v6h6", "M12 11v6", "M9 14h6"), listOf(), false)
    val clock = IconSpec(listOf("M12 6v6l4 2"), listOf(floatArrayOf(12f, 12f, 10f)), false)
    val headphones = IconSpec(listOf("M3 18v-6a9 9 0 0 1 18 0v6", "M21 19a2 2 0 0 1 -2 2h-1a2 2 0 0 1 -2 -2v-3a2 2 0 0 1 2 -2h3v5zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2 -2v-3a2 2 0 0 0 -2 -2H3v5z"), listOf(), false)
    val checkCircle = IconSpec(listOf("M22 11.08V12a10 10 0 1 1 -5.93 -9.14", "M22 4L12 14.01l-3 -3"), listOf(), false)
    val xCircle = IconSpec(listOf("M15 9l-6 6", "M9 9l6 6"), listOf(floatArrayOf(12f, 12f, 10f)), false)
    val info = IconSpec(listOf("M12 8v4", "M12 16h.01"), listOf(floatArrayOf(12f, 12f, 10f)), false)
    val trash = IconSpec(listOf("M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"), listOf(), false)
    val check = IconSpec(listOf("M5 13l4 4L19 7"), listOf(), false)
}
