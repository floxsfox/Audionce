# Audionce — aplikasi Android (Kotlin, native)

Terjemahan penuh dari `index.html` Audionce ke aplikasi Android asli: **bukan WebView**, semua mesin audio,
visualizer, UI, dan export ditulis ulang dengan Kotlin + Jetpack Compose.

## Cara build APK dari HP (tanpa PC)

1. Di github.com buat repo baru (nama bebas, boleh Private).
2. **Add file → Upload files** → pilih `Audionce-Project.zip` (jangan diekstrak) → **Commit changes**.
3. **Add file → Create new file** → isi nama file: `.github/workflows/build-apk.yml`
   → tempel seluruh isi file `build-apk.yml` → **Commit changes**.
4. Buka tab **Actions**. Build jalan sendiri (sekitar 8–12 menit pada build pertama).
5. Setelah hijau, buka halaman utama repo → **Releases** → unduh file `Audionce-buildN.apk` → install
   (izinkan "Install dari sumber ini" saat diminta).

Build berikutnya: ganti ZIP dengan yang baru (upload nama yang sama) atau tekan **Actions → Build Audionce APK → Run workflow**.
APK baru bisa langsung menimpa yang lama karena memakai keystore yang sama (`audionce.keystore` di dalam proyek).

Jika build gagal: buka run yang merah → bagian **Summary** berisi daftar error. Salin dan kirim ke Claude.

> Kalau ZIP sudah diekstrak ke repo (ada `settings.gradle.kts` di root), workflow juga langsung membangunnya.
> File workflow yang sama sudah ada di dalam ZIP pada `.github/workflows/build-apk.yml`.

## Fitur (sama dengan versi HTML)

- Buka file MP3 / FLAC / WAV / OGG / M4A, cover art otomatis dari tag file.
- Wave Candy (stabil, lebar jendela tetap), Bars, Circular — ketuk visualizer untuk ganti mode.
- Kontrol: play/pause, ±5 s, ±10 s, seek bar, volume, loop, mute.
- Efek: Slowed (0.5×–1×), Reverb konvolusi (Wet / Room / Decay), Spatial 3D / 8D / 10D.
- Metadata: judul, artis, label, cover art.
- Export: WAV, M4A (AAC), atau video MP4 1280×720 50 fps (Wave Candy + cover art) dengan efek terpilih.
  Hasil disimpan di `Music/Audionce` dan `Movies/Audionce`.
- Musik tetap jalan saat layar mati (layanan foreground dengan notifikasi).

## Struktur kode

```
app/src/main/java/com/audionce/studio/
  MainActivity.kt, AudionceApp.kt, AppController.kt, PlaybackService.kt
  audio/   Fft, Reverb (konvolusi FFT berpartisi), DspChain, AudioDecoder, PlayerEngine
  export/  OfflineRenderer, MediaExporter (AAC + H.264 + muxer), VideoFrameRenderer, MediaSaver
  vis/     WaveCandy (trigger stabil), Bars, Circular
  ui/      Compose: MainScreen, Components, VisualizerView, Icons
```

## Versi alat build (dikunci)

Gradle 8.13 · Android Gradle Plugin 8.13.2 · Kotlin 2.2.20 · Compose BOM 2025.09.01 · JDK 17 · compileSdk 36 · minSdk 29.
